@extends('layouts.app')

@section('content')
<section id="content-body-expositores">
    <div class="container-fluid">
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
    </div>
</section>

@endsection