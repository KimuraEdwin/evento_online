

<?php $__env->startSection('content'); ?>
<section id="content-body-expositores">
    <div class="container-fluid">
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
        <div class="row justify-content-sm-center">
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
            <div class="col-md-3 mx-2 d-flex stand-bg justify-content-center align-items-center">
                <img src="https://picsum.photos/200" alt="">
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\pratisys\app_feiras_online\resources\views/feiras/feira.blade.php ENDPATH**/ ?>