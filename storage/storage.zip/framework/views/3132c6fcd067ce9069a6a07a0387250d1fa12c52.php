

<?php $__env->startSection('content'); ?>
    <section id="content-body">
        <div class="container-fluid px-0">
            <div id="et-vmmv-slider" class="et-vmmv-slider">
                <div class="et-vmmv-slides-container">
                    <ul class="et-vwmv-slider-imgs">
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                        <li><img src="https://picsum.photos/200" alt="" /></li>
                    </ul>
                </div>
                <ul class="et-vwmv-slider-nav">
                    <li><button><span></span></button></li>
                    <li><button><span></span></button></li>
                    <li><button><span></span></button></li>
                    <li><button><span></span></button></li>
                    <li><button><span></span></button></li>
                    <li><button><span></span></button></li>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\pratisys\app_feiras_online\resources\views/index.blade.php ENDPATH**/ ?>