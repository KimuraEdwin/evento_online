[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\projetos\pratisys\app_feiras_online\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>