<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\projetos\pratisys\app_feiras_online\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>