<?php echo e($slot); ?>

<?php /**PATH C:\projetos\pratisys\app_feiras_online\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>